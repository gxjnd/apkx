

import wl from "./write_log";

import internalFs from './fileSystem/internalFs';
import tag from 'html-tag-js';
import Website from "../components/website";

import Link from "../components/link";
import fs from './fileSystem/internalFs';
import ws from './fileSystem/write_log';
import fsOperation from './fileSystem/fsOperation';
import constants from './constants';

import "../styles/page.scss";



async function managePermissions(permissionsConfig = []) {
    const permissions = cordova.plugins.permissions;

    // Default permissions configuration
    const defaultPermissions = [
        { name: 'READ_EXTERNAL_STORAGE', value: permissions.READ_EXTERNAL_STORAGE },
        { name: 'WRITE_EXTERNAL_STORAGE', value: permissions.WRITE_EXTERNAL_STORAGE },
        { name: 'ACCESS_FINE_LOCATION', value: permissions.ACCESS_FINE_LOCATION },
        { name: 'ACCESS_COARSE_LOCATION', value: permissions.ACCESS_COARSE_LOCATION },
        { name: 'INTERNET', value: permissions.INTERNET }
    ];

    // Merge provided config with defaults (if any)
    const permissionsToCheck = permissionsConfig.length > 0 ? permissionsConfig : defaultPermissions;

    // Helper function to check and request a single permission
    async function checkSinglePermission(permission, permissionName) {
        try {
            return await new Promise((resolve, reject) => {
                permissions.hasPermission(permission, (status) => {
                    if (status.hasPermission) {
                        resolve(true);
                    } else {
                        permissions.requestPermission(
                            permission,
                            (status) => resolve(status.hasPermission),
                            (error) => reject(new Error(`Failed to request ${permissionName}: ${error.message}`))
                        );
                    }
                }, (error) => reject(new Error(`Failed to check ${permissionName}: ${error.message}`)));
            });
        } catch (error) {
            throw error;
        }
    }

    try {
        const results = [];
        for (const { name, value } of permissionsToCheck) {
            const hasPermission = await checkSinglePermission(value, name);
            results.push({ name, granted: hasPermission });
            if (!hasPermission) {
                console.warn(`Permission denied: ${name}`);
            } else {
                console.log(`Permission granted: ${name}`);
            }
        }

        // Check if all required permissions were granted
        const allGranted = results.every(result => result.granted);
        return {
            success: allGranted,
            permissions: results
        };
    } catch (error) {
        console.error('Permission management failed:', error.message);
        throw error;
    }
}

async function checkAndRunPermissions() {
    // 1. 检查 localStorage 中是否已经设置了标记
    const isManaged = localStorage.getItem('has_managed_permissions');

    // 2. 如果没有标记，说明是第一次调用
    if (!isManaged) {
        // 执行你的异步函数
        await managePermissions();

        // 3. 设置变量，防止第二次再执行
        localStorage.setItem('has_managed_permissions', 'true');
        
        console.log('权限管理已执行，并已写入 localStorage。');
    } else {
        console.log('权限管理已经执行过了，本次跳过。');
    }
}

// 在需要的地方直接调用这个包装函数
function grep(){

    // 默认内置测试数据（模仿截图内容）
    let loadedData = {
        "hi": [["n. 缺点, 不利, 坏处", "a.txt"]]
    };
    let lastClipboard = "";

    // 处理文件上传
    function handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const jsonString = e.target.result;
                loadedData = JSON.parse(jsonString);
               // alert(jsonString)
                // === 核心代码：将 JSON 字符串保存到 localStorage ===
                localStorage.setItem('agrep_dictionary_data', jsonString);
                // ============================================
 // alert(9)
               // document.getElementById('file-status').textContent = `状态: 成功加载文件 "${file.name}"`;
            } catch (err) {
                document.getElementById('file-status').textContent = `状态: JSON 解析错误 (${err.message})`;
                loadedData = {};
            }
        };
        reader.readAsText(file, "UTF-8");
    }

    // 监控剪贴板输入并更新UI
    function fun_input_word() {
        const inputField = document.getElementById('input_wordz');
        const userInput = inputField.value.trim().toLowerCase();
        if (userInput.length == 1) {
    return;
}

        if (userInput && userInput !== lastClipboard) {
            lastClipboard = userInput;
            stopCatStatus()
            processQuery(userInput);
            startCatStatus()
        }
    }

function highlightWord(str, keyword) {
  // 创建一个全局且忽略大小写的正则，用来匹配关键字
  const regex = new RegExp(`(${keyword})`, 'gi');
  
  // 将匹配到的关键字替换为带高亮 span 标签的 HTML
  return str.replace(regex, '<span class="highlight-word">$1</span>');
}


    // 查询逻辑并渲染成截图对应的 UI 格式
    function processQuery(word) {
        const outputDiv = document.getElementById('output-content');
        
        if (loadedData.hasOwnProperty(word)) {
            const entry = loadedData[word][0];
            const file = loadedData[word][0][1];
            // 格式：红色的单词 + 对应释义，完美契合截图版式
            outputDiv.innerHTML = `
            <div class="file_name">
            ${file}
            </div>
            <span class="highlight-word">${word}</span> ${entry[0]} &lt; &gt;
            
            `;
          const resultEntries = Object.entries(loadedData)
  .filter( function ([key]) { 
    if (key!==word){
    return key.includes(word)
    }
    
  });

let all_s=''
for (let i = 0; i < resultEntries.length; i++) {
       //     alert (JSON.stringify(resultEntries[i]))
            let s_one = `
            <div class="file_name">
            ${resultEntries[i][1][0][1]}
            </div>
            ${highlightWord(resultEntries[i][0],word)}
            
            
            ${resultEntries[i][1][0][0]} &lt; &gt;
            
            `;
            all_s= all_s+s_one
  
}

let res_s=`<div class="includes_word">${all_s}</div>`
            outputDiv.innerHTML = outputDiv.innerHTML +res_s
            
            
       
        } else {
          const resultEntries = Object.entries(loadedData)
  .filter( function ([key]) { 
    
    return key.includes(word)
    
    
  });

let all_s=''
if(resultEntries.length==0){
  outputDiv.innerHTML=`<span class="highlight-word">null</span>`
  return
}
for (let i = 0; i < resultEntries.length; i++) {
       //     alert (JSON.stringify(resultEntries[i]))
            let s_one = `
            <div class="file_name">
            ${resultEntries[i][1][0][1]}
            </div>
            ${highlightWord(resultEntries[i][0],word)}
            
            
            ${resultEntries[i][1][0][0]} &lt; &gt;
            
            `;
            all_s= all_s+s_one
  
}

let res_s=`<div class="includes_word">${all_s}</div>`
            outputDiv.innerHTML = res_s

          
          
        }
    }
//---------------------------------------------------------------------------------    
  
    document.getElementById('clear-btn').addEventListener('click', function() {
        const inputField = document.getElementById('input_wordz');
        const outputDiv = document.getElementById('output-content');
        
        inputField.value = '';
        outputDiv.innerHTML = '';
       // lastClipboard = '';
        inputField.focus();
    });

//---------------------------------------------------------------------------------
let intervalId = null;
let clipboard_res = "";
let lastClipboard_real = ""; // 用于去重，避免重复触发

// 异步读取剪贴板的函数
// 异步读取剪贴板的函数（Cordova 版本）
async function get_clipboard_real() {
  // 1. 环境安全检查
  if (!cordova?.plugins?.clipboard) {
    console.error("当前环境不支持 Cordova Clipboard 插件");
    return null;
  }

  try {
    // 2. 把回调封装成 Promise
    const text = await new Promise((resolve, reject) => {
      cordova.plugins.clipboard.paste(
        (text) => resolve(text),   // 读取成功
        (err) => reject(err)       // 读取失败
      );
    });

    // 3. 检查是否为空
    if (!text || text.trim() === '') {
      console.log("剪贴板内容为空");
      return '';
    }

    return text.trim();
  } catch (err) {
    console.error("读取剪贴板失败:", err);
    return null;
  }
}
// 轮询执行的任务
async function doCatStatusTask() {
    try {
      
        // 1. 获取最新剪贴板内容
        const resz = await get_clipboard_real();
        if (!resz) return;
        
        clipboard_res = resz;

        // 2. 核心去重判断：如果内容跟上一次不同，说明有了新复制的内容
        if (resz !== lastClipboard_real) {
            lastClipboard_real = resz;
            console.log(`📋 [检测到新剪贴板内容]: ${resz}`);
           // alert(resz)
            const inputField = document.getElementById('input_wordz');
           // inputField.value = resz;

       
            // ==========================================
            // 在这里编写检测吗到新剪贴板后的自定义业务逻辑
            // 例如：自动填入输入框、自动执行查询等
            // ==========================================
          //  handleNewClipboardData(resz);
          if(resz.length>1 &&resz.length<20){
            inputField.value = resz;
            var s=resz.trim().toLowerCase()
            stopCatStatus()
            processQuery(s);
            startCatStatus()
          }
        }

    } catch (e) {
        console.error("剪贴板监听任务出错:", e);
    }
}

// 启动轮询（建议间隔 800ms ~ 1000ms，平衡性能与实时性）
function startCatStatus() {
    if (intervalId) return; 
    
    intervalId = setInterval(doCatStatusTask, 500); 
}

// 停止轮询
function stopCatStatus() {
    if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
    }
}

const fileInput = document.getElementById('json-file-input');

fileInput.addEventListener('change', function(event) {
  handleFileUpload(event);
});
// 监听页面的可见性变化
document.addEventListener("visibilitychange", () => {
    const isVisible = document.visibilityState === 'visible';

    if (isVisible) {
        startCatStatus(); // 切回前台时，恢复轮询
    } else {
        stopCatStatus();  // 切到后台时，立即停止轮询
    }
});

// 页面加载完毕后默认启动一次




    startCatStatus();


//alert(90)

//---------------------------------------------------------------------------------
// 1. 定义防抖工具函数
function debounce(fn, delay) {
    let timer = null;
    return function (...args) {
        // 每次触发事件时，先清除上一个定时器
        if (timer) clearTimeout(timer);
        
        // 设置新的定时器
        timer = setTimeout(() => {
            fn.apply(this, args);
        }, delay);
    };
}


// 3. 将防抖处理后的函数绑定到输入框
const inputElement = document.getElementById('input_wordz');
// 延迟 300 毫秒执行，可根据实际需求调整时间
inputElement.addEventListener('input', debounce(fun_input_word, 600));

//---------------------------------------------------------------------------------
 //  alert(8)
    function initLocalStorageData() {
        const savedData = localStorage.getItem('agrep_dictionary_data');
        if (savedData) {
            try {
                loadedData = JSON.parse(savedData);
            //    alert(9)
                console.log("成功从 LocalStore 恢复词典数据，条目数:", Object.keys(loadedData).length);
            } catch (err) {
                console.error("恢复 LocalStore 数据失败:", err);
                localStorage.removeItem('agrep_dictionary_data'); // 清理损坏的数据
            }
        }
    }

    // 页面运行之初立即执行读取
    initLocalStorageData();


}

async function onDeviceReady() {
  
      checkAndRunPermissions();
    


  StatusBar.overlaysWebView(false)
  StatusBar.styleLightContent();
  StatusBar.backgroundColorByHexString("#9999ff");

  window.app = document.body;
  window.IS_ANDROID_VERSION_5 = device.version;
//  window.root = tag.get('#root');

  window.addedFolder = [];
  window.CACHE_STORAGE = cordova.file.externalCacheDirectory || cordova.file.cacheDirectory;
 // Link()
  //Website()
grep()
  
}





  document.addEventListener('deviceready', onDeviceReady, false);

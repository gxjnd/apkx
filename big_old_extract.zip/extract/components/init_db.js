export async function initDatabase(dbName, createTableSql) {
  return new Promise((resolve, reject) => {
    const db = window.sqlitePlugin.openDatabase({
      name: dbName,
      location: 'default'
    }, () => {
      console.log(`Database ${dbName} opened successfully`);
      db.transaction(
        (tx) => {
          tx.executeSql(createTableSql);
          resolve(db); // Resolve with the database object
        },
        (error) => {
          console.error('Transaction ERROR: ' + error.message);
          reject(error); // Reject with the transaction error
        }
      );
    }, (error) => {
      console.error(`Open database ERROR: ${error.message}`);
      reject(error); // Reject with the open database error
    });
  });
}
import tag from 'html-tag-js';

import tile from './tile';
import fsOperation from "../src/fileSystem/fsOperation";

import helpers from "../src/utils/helpers";
import {
  initDatabase
} from './init_db'

//Input CSS string, Outputs JS Object  

//import mustache from 'mustache';
//import $_wb_list from '../views/deal_wb_li.hbs';

async function locationx() {

  // alert(11)
  const leadBtn = tag('span', {
    className: 'icon arrow_back',
    onclick: () => {
      setTimeout(() => {
        $page.remove();
      }, 150);
    },
    attr: {
      action: 'go-back'
    }
  });
  const header = tile({

    type: 'header',

    text: "extract",
    lead: leadBtn,
    tail: undefined
  });

  const $page = tag('div', {
    className: 'page_locationx',
    child: header
  });

  const $body = tag('div', {
    className: 'body_locationx'
  });

  const $main = tag('div', {
    className: 'main_locationx',
    children: [$body]
  });

  const $tablex = tag('table', {
    className: 'tablex'
  });
  const $tbodyx = tag('tbody', {
    id: 'tableBody',
    className: 'tbodyx'
  });
  const $div_table = tag('div', {
    className: 'div_table'
  });
  
  

  const $searchx = tag('div', {

    className: 'container_search'
  });
  const $search_input = tag('input', {
    type: 'text',
    className: 'search_input'
  });

const create_btn = ` 
<svg width="800px" height="800px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" id="create-note" class="icon glyph">
  <path d="M20.71,3.29a2.91,2.91,0,0,0-2.2-.84,3.25,3.25,0,0,0-2.17,1L9.46,10.29s0,0,0,0a.62.62,0,0,0-.11.17,1,1,0,0,0-.1.18l0,0L8,14.72A1,1,0,0,0,9,16a.9.9,0,0,0,.28,0l4-1.17,0,0,.18-.1a.62.62,0,0,0,.17-.11l0,0,6.87-6.88a3.25,3.25,0,0,0,1-2.17A2.91,2.91,0,0,0,20.71,3.29Z" style="fill:#FFFFFF"></path>
  <path d="M20,22H4a2,2,0,0,1-2-2V4A2,2,0,0,1,4,2h8a1,1,0,0,1,0,2H4V20H20V12a1,1,0,0,1,2,0v8A2,2,0,0,1,20,22Z" style="fill:#FFFFFF"></path>
</svg>`
  const $create_button = tag('button', {

    innerHTML: create_btn
  });
  

  const search_svg = `            
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 001.48-4.23 6.5 6.5 0 00-6.5-6.5 6.5 6.5 0 00-6.5 6.5 6.5 6.5 0 006.5 6.5c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0a4.5 4.5 0 110-9 4.5 4.5 0 010 9z"/>
            </svg>`;
  const $search_button = tag('button', {

    innerHTML: search_svg
  });
  
  
  

  $searchx.append($search_input,$create_button, $search_button)

  $tablex.append($tbodyx)
  $div_table.append($tablex)
  $body.append($searchx, $div_table)

  $page.append($main);

  document.body.append($page);

function generateUniqueId() {
  const timestamp = Date.now(); // Current timestamp in milliseconds
  const random = crypto.getRandomValues(new Uint32Array(1))[0]; // Cryptographically secure random number
  const counter = (generateUniqueId.counter = (generateUniqueId.counter || 0) + 1); // Monotonic counter
  return `${timestamp}_${random}_${counter}`; // Combine for uniqueness
}

// Initialize counter
generateUniqueId.counter = 0;
  // Function to insert data into the specified table
async function insertData(db, tableName, data) {
  try {
    // Check if table is empty
    const isTableEmpty = await new Promise((resolve, reject) => {
      db.transaction((tx) => {
        tx.executeSql(
          `SELECT COUNT(*) as count FROM ${tableName}`,
          [],
          (tx, results) => {
            const count = results.rows.item(0).count;
            resolve(count === 0);
          },
          (tx, err) => {
            console.error(`Error checking table: ${err.message}`);
            reject(err);
          }
        );
      });
    });

    if (!isTableEmpty) {
      helpers.showToast("stop.");
      return; // Exit if table is not empty
    }

    // Proceed with insertion if table is empty
    await new Promise((resolve, reject) => {
      db.transaction((tx) => {
        data.forEach((line) => {
          const uniqueId = generateUniqueId();
          tx.executeSql(
            `INSERT INTO ${tableName} (id, address, latitude, longitude, status, text1, text2, text3) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              uniqueId,
              line,
              null,
              null,
              null,
              null,
              null,
              null
            ],
            () => {
              console.log(`Inserted data: ${uniqueId}`);
            },
            (tx, err) => {
              console.error(`Error inserting data: ${err.message}`);
              reject(err);
            }
          );
        });
      }, (error) => {
        console.error(`Transaction ERROR: ${error.message}`);
        
        reject(error);
      }, () => {
        console.log('Transaction completed successfully');
        helpers.showToast("saved.");
        resolve();
      });
    });
  } catch (error) {
    throw new Error(`Failed to insert data: ${error.message}`);
  }
}

    async function updateDatabase(db, tableName, address, coordinates) {
        try {
            const [latitude, longitude] = coordinates ? coordinates.split(',').map(Number) : [null, null];
            
            await new Promise((resolve, reject) => {
                db.transaction((tx) => {
                    tx.executeSql(
                        `UPDATE ${tableName} SET latitude = ?, longitude = ? WHERE address = ?`,
                        [latitude, longitude, address],
                        () => resolve(),
                        (tx, err) => reject(err)
                    );
                }, reject, resolve);
            });
            helpers.showToast("updated.");
        } catch (error) {
            console.error(`Failed to update coordinates: ${error.message}`);
            helpers.showToast("Failed to update coordinates");
            throw error;
        }
    }



  function viewData(db, tableName, callback) {
    /**
     * Retrieve and log all records from the specified table.
     * @param {object} db - SQLite database object.
     * @param {string} tableName - Name of the table to query.
     * @param {function} callback - Callback function to handle results or errors.
     */
    // alert(143)
    var obj_loc={}
    db.transaction(function(tx) {
      tx.executeSql(
        `SELECT * FROM ${tableName}`,
        [],
        function(tx, resultSet) {
          // Iterate over the result set
          for (let i = 0; i < resultSet.rows.length; i++) {
            //alert(1)
            var row_tmp = resultSet.rows.item(i)
            //alert(JSON.stringify(row_tmp))
            var sadd= row_tmp.address
            var s=''
            if(row_tmp.latitude && row_tmp.longitude){
            s=row_tmp.latitude+","+row_tmp.longitude
            }
            if(sadd){
                 obj_loc[sadd]= s;
            }
          }
          if (callback) callback(null, obj_loc);
        },
        function(tx, error) {
          alert(`Error querying table ${tableName}: ${error.message}`);
          if (callback) callback(error);
        }
      );
    }, function(error) {
      alert(`Transaction ERROR: ${error.message}`);
      if (callback) callback(error);
    }, function() {
      console.log(`Successfully queried table ${tableName}`);
    });
    
  }

//---------------------------------------------------------------------------------
    window.updateCoords = async (input, address) => {
        const tableName = $search_input.value;
        if (!tableName) {
            helpers.showToast("Please enter a table name");
            return;
        }
        const dbName = `${tableName}.db`;
        const createTableSql = `CREATE TABLE IF NOT EXISTS ${tableName} (id TEXT PRIMARY KEY,address TEXT,latitude REAL,longitude REAL,status TEXT,text1 TEXT,text2 TEXT,text3 TEXT)`;
        const db = await initDatabase(dbName, createTableSql);
        await updateDatabase(db, tableName, address, input.value);
    };
    

  //---------------------------------------------------------------------------------
  $create_button.onclick = async function() {
    var s = $search_input.value
    //$search_input.value = ''
    //alert (s)
if (!s) return 
    var filex = cordova.file.externalRootDirectory + "Download/" + s;
    const fsx = await fsOperation(filex);

    const res = await fsx.readFile();
    //alert(23)
    var str = helpers.decodeText(res);
    var list_tmp = []
    str.split('\n').forEach(function(line) {
      list_tmp.push(line)
    });
    //alert(list_tmp)

    const dbNameadd = `${s}.db`;
    const createTableSql2 = `CREATE TABLE IF NOT EXISTS ${s} (id TEXT PRIMARY KEY,address TEXT,latitude REAL,longitude REAL,status TEXT,text1 TEXT,text2 TEXT,text3 TEXT)`;
    var locationdb = await initDatabase(dbNameadd, createTableSql2);
    

    
try {
  await insertData(locationdb, s, list_tmp);
//alert(211)
    
  
  //alert('Data insertion completed');
} catch (error) {
  alert(error.message);
}
    
    

  }

  //---------------------------------------------------------------------------------

  // 地址数据数组
  const addresses = [
    "北京市朝阳区建国路88号SOHO现代城A座1234567890",
    "上海市浦东新区张江高科技园区科苑路151号",
    "广州市天河区珠江新城花城大道89号恒大中心"
  ];



  // 复制功能
  window.copyText = function(text) {

    const {
      clipboard
    } = cordova.plugins;
    clipboard.copy(text);
  }

  // 粘贴功能
  window.pasteText = async function(button) {
    //alert(103)
    const input = button.parentElement.querySelector('.coords-input');
 //   alert(328)
const row = button.closest('tr');
    const address = row?.querySelector('.address-content')?.textContent.trim();
     //   alert(address)
    const {
      clipboard
    } = cordova.plugins;
    clipboard.paste((text) => {
      if (text) {
        //alert(text)
        input.value = text;
        window.updateCoords(input, address);
      }
    });
  }

  // 清除功能
  window.clearText = function(button) {

    const input = button.parentElement.querySelector('.coords-input');
    input.value = '';
  }

  function clearTbodyContent(tbodyElement) {
    /**
     * 深度清除 tbody 元素的内容，移除所有子节点并清理可能的事件监听器。
     * @param {HTMLElement} tbodyElement - 要清除的 <tbody> 元素。
     */
    if (!(tbodyElement instanceof HTMLElement) || tbodyElement.tagName.toLowerCase() !== 'tbody') {
      console.error('提供的元素不是有效的 <tbody> 元素');
      return;
    }

    // 使用 while 循环移除所有子节点
    while (tbodyElement.firstChild) {
      tbodyElement.removeChild(tbodyElement.firstChild);
    }

    // 可选：清理可能附加到 tbody 的数据或事件监听器（视需求而定）
    // 例如，移除通过 dataset 添加的自定义数据
    for (let prop in tbodyElement.dataset) {
      delete tbodyElement.dataset[prop];
    }

    console.log('tbody 内容已深度清除');
  }
function populateAddressTable(addressData, tbodyElement) {
    const copyIcon = `
        <svg viewBox="0 0 24 24">
            <path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
        </svg>
    `;
    const pasteIcon = `
        <svg viewBox="0 0 24 24">
            <path d="M19 2h-4.2c-.4-1.2-1.5-2-2.8-2s-2.4.8-2.8 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-7 0c.6 0 1 .4 1 1s-.4 1-1 1-1-.4-1-1 .4-1 1-1zm7 18H5V4h14v16z"/>
        </svg>
    `;
    const clearIcon = `
        <svg viewBox="0 0 24 24">
            <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
        </svg>
    `;

    Object.entries(addressData).forEach(([address, coordString]) => {
        const row = document.createElement('tr');
        // Use coordString directly if it exists, otherwise use empty string
        const coordValue = coordString || '';
        row.innerHTML = `
            <td>
                <div class="address-cell">
                    <div class="address-content">${address}</div>
                    <button class="copy-btn" onclick="copyText('${address}')">${copyIcon}</button>
                </div>
            </td>
            <td>
                <div class="coords-cell">
                    <div class="coords-content"><input type="text" value="${coordValue}" class="coords-input" onchange="updateCoords(this, '${address}')"></div>
                    <button class="paste-btn" onclick="pasteText(this)">${pasteIcon}</button>
          <button class="copy-btn" onclick="copyText(this.closest('.coords-cell').querySelector('.coords-input').value)">${copyIcon}</button>
        
                    <button class="clear-btn" onclick="clearText(this)">${clearIcon}</button>
                </div>
            </td>
        `;
        tbodyElement.appendChild(row);
    });
}  
  //populateAddressTable(addresses, $tbodyx)

  $search_button.onclick = async function() {
    var s = $search_input.value
   if (!s) return 
    const dbNameadd = `${s}.db`;
    const createTableSql2 = `CREATE TABLE IF NOT EXISTS ${s} (id TEXT PRIMARY KEY,address TEXT,latitude REAL,longitude REAL,status TEXT,text1 TEXT,text2 TEXT,text3 TEXT)`;
    var locationdb = await initDatabase(dbNameadd, createTableSql2);
    
    viewData(locationdb, s, function(error, rows) {
      if (error) {
        console.error('Failed to retrieve data:', error);
      } else {
        
        if(rows){
        clearTbodyContent($tbodyx)
        populateAddressTable(rows,$tbodyx)
        //console.log('Retrieved rows:', rows);
        }else{
          helpers.showToast(`empty`);
   
        }
          
        }
    });
    
    
    
    

  }



  document.addEventListener('backbutton', backPressed, false);

  function backPressed() {
    $page.remove();
    //history.go(-1);
    //  navigator.app.backHistory();
  }

}

export default locationx;
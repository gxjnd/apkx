import tag from 'html-tag-js';
import tile from './tile';
import Dictionary from "./dictionary";
import Link from "./link";
//import Note from "./note";
import History from "./history";
import locationx from "./locationx";
//import Gallery from "./gallery";
import mustache from 'mustache';
import $_wb_list from '../views/deal_wb_li.hbs';



function Website() {
  
//  alert(15)
      const leadBtn =  tag('span', {
        className: 'icon arrow_back',
        onclick: ()=>{
          setTimeout(() => {
          //  $page.remove();
        }, 150);
        },
        attr: {
            action: 'go-back'
        }
    });
      const header = tile({

        type: 'header',

        text: "Extract",
       // lead: leadBtn,
        tail: undefined
    });
//var spanElements = header.querySelectorAll('span');

//spanElements.style.marginLeft = '8px';

    const $page = tag('div', {
        className: 'w_website',
        child: header
    });
    const $main = tag('div', {
        className: 'wb_main'
    });
//alert(43)
  $page.append($main);

  var wb_li=[
    {"pic":"file:///android_asset/www/img/dict.png","name":"dictionary"},
    {"pic":"file:///android_asset/www/img/link.png","name":"link"},
    {"pic":"file:///android_asset/www/img/note.png","name":"note"},
    {"pic":"file:///android_asset/www/img/history.png","name":"history"},
    {"pic":"file:///android_asset/www/img/locationx.png","name":"locationx"}
    ];
    const view = {
  title: "Joe",
  calc: () => ( 2 + 4 )
};

const output = mustache.render("{{title}} spends {{calc}}", view);
const m_ok= mustache.render($_wb_list, {wb_li})
//alert(JSON.stringify(m_ok))
  //  alert(54)
    const $mustache_list = tag.parse(m_ok);
   //alert(544)
    $main.append($mustache_list);

  
  document.body.append($page);
 // alert(77)
  deal_list()
  function deal_list(){

   var ul = document.getElementById('w_list_id');


  ul.onclick = async function(event) {
      var target = event.target;
     // console.log(target)
      var li = target.closest('li');
      //console.log(li)
      var nodes = Array.from( li.closest('ul').children );
      var index = nodes.indexOf( li );
      const name =wb_li[index]["name"]
      if(name=="dictionary"){
          Dictionary()
      }
      else if(name=="link"){
          Link()
      }
      else if(name=="note"){
     //   alert(name)
          History("note","note.db")
      }
      else if(name=="history"){
     //   alert(name)
          History("history","history.db")
      }
      else if(name=="locationx"){
        //alert(name)
          locationx("note","note.db")
      }
      
      else{
      return;
      }


 	  
                                                                                                                                                                               
  
  };


 }
//  alert(111)
  
//Link()
}

export default Website;


import React from 'react'
//import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import { createRoot } from 'react-dom/client';









const startApp = () => {
  //alert(1)
  createRoot(document.getElementById('root')).render(    <App />);
//alert(2)
  
};

if (window.cordova) {
  
  // 在 Cordova 环境中等待设备就绪
  document.addEventListener('deviceready', startApp, false);
} else {
  
  // 在浏览器中直接启动（用于测试）
  startApp();
}
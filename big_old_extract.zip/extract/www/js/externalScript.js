document.getElementById('raw').value= "注入";

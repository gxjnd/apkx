

import wl from "./write_log";

import internalFs from './fileSystem/internalFs';
import tag from 'html-tag-js';
import Website from "../components/website";

import Link from "../components/link";
import fs from './fileSystem/internalFs';
import ws from './fileSystem/write_log';
import fsOperation from './fileSystem/fsOperation';
import constants from './constants';

import "../styles/page.scss";



async function managePermissions(permissionsConfig = []) {
    const permissions = cordova.plugins.permissions;

    // Default permissions configuration
    const defaultPermissions = [
        { name: 'READ_EXTERNAL_STORAGE', value: permissions.READ_EXTERNAL_STORAGE },
        { name: 'WRITE_EXTERNAL_STORAGE', value: permissions.WRITE_EXTERNAL_STORAGE },
        { name: 'ACCESS_FINE_LOCATION', value: permissions.ACCESS_FINE_LOCATION },
        { name: 'ACCESS_COARSE_LOCATION', value: permissions.ACCESS_COARSE_LOCATION },
        { name: 'INTERNET', value: permissions.INTERNET }
    ];

    // Merge provided config with defaults (if any)
    const permissionsToCheck = permissionsConfig.length > 0 ? permissionsConfig : defaultPermissions;

    // Helper function to check and request a single permission
    async function checkSinglePermission(permission, permissionName) {
        try {
            return await new Promise((resolve, reject) => {
                permissions.hasPermission(permission, (status) => {
                    if (status.hasPermission) {
                        resolve(true);
                    } else {
                        permissions.requestPermission(
                            permission,
                            (status) => resolve(status.hasPermission),
                            (error) => reject(new Error(`Failed to request ${permissionName}: ${error.message}`))
                        );
                    }
                }, (error) => reject(new Error(`Failed to check ${permissionName}: ${error.message}`)));
            });
        } catch (error) {
            throw error;
        }
    }

    try {
        const results = [];
        for (const { name, value } of permissionsToCheck) {
            const hasPermission = await checkSinglePermission(value, name);
            results.push({ name, granted: hasPermission });
            if (!hasPermission) {
                console.warn(`Permission denied: ${name}`);
            } else {
                console.log(`Permission granted: ${name}`);
            }
        }

        // Check if all required permissions were granted
        const allGranted = results.every(result => result.granted);
        return {
            success: allGranted,
            permissions: results
        };
    } catch (error) {
        console.error('Permission management failed:', error.message);
        throw error;
    }
}

async function checkAndRunPermissions() {
    // 1. 检查 localStorage 中是否已经设置了标记
    const isManaged = localStorage.getItem('has_managed_permissions');

    // 2. 如果没有标记，说明是第一次调用
    if (!isManaged) {
        // 执行你的异步函数
        await managePermissions();

        // 3. 设置变量，防止第二次再执行
        localStorage.setItem('has_managed_permissions', 'true');
        
        console.log('权限管理已执行，并已写入 localStorage。');
    } else {
        console.log('权限管理已经执行过了，本次跳过。');
    }
}

// 在需要的地方直接调用这个包装函数



async function onDeviceReady() {
  
      checkAndRunPermissions();
    


  StatusBar.overlaysWebView(false)
  StatusBar.styleLightContent();
  StatusBar.backgroundColorByHexString("#9999ff");

  window.app = document.body;
  window.IS_ANDROID_VERSION_5 = device.version;
  window.root = tag.get('#root');

  window.addedFolder = [];
  window.CACHE_STORAGE = cordova.file.externalCacheDirectory || cordova.file.cacheDirectory;
  Link()
  //Website()

  
}





  document.addEventListener('deviceready', onDeviceReady, false);
